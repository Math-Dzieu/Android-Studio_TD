package com.example.td1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    int mCounter = 0;
    Button toastBtn;
    Button countBtn;
    Button randomBtn;
    TextView counterField;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toastBtn = (Button) findViewById(R.id.btnToast);
        countBtn = (Button) findViewById(R.id.btnCount);
        randomBtn = (Button) findViewById(R.id.btnRandom);
        counterField = (TextView) findViewById(R.id.textCount);

        toastBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "You click", Toast.LENGTH_LONG).show();
            }
        });

        countBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mCounter++;
                counterField.setText(Integer.toString(mCounter));
            }
        });

        randomBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRandomScreen();
            }
        });
    }

    public void openRandomScreen(){
        Intent intent = new Intent(MainActivity.this, Activity2.class);
        startActivity(intent);
    }

}

/*
Random r = new Random();
int i1 = r.nextInt(80 - 65) + 65;
This gives a random integer between 65 (inclusive) and 80 (exclusive), one of 65,66,...,78,79.

int max = 16;
int min = 0;
Random random = new Random();
int randomNumber = random.nextInt(max–min) + min;

                int randomNumb = random.nextInt(max-min) + min;
                randomField.setText(Integer.toString(randomNumb));
 */


/*
    TextView randomField;
    int max = 16;
    int min = 0;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        randomField = (TextView) findViewById(R.id.randomNumber);

        int randomNumb = random.nextInt(max-min) + min;
        randomField.setText(Integer.toString(randomNumb));
    }

 */
