package com.example.td1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Activity2 extends AppCompatActivity {

    Button back;
    TextView randomField;
    int max = 16;
    int min = 0;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        randomField = (TextView) findViewById(R.id.randomNumber);
        back = (Button) findViewById(R.id.Return);

        int randomNumb = random.nextInt(max-min) + min;
        randomField.setText(Integer.toString(randomNumb));

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                //returnHome();
            }
        });
    }
/*
    public void returnHome(){
        Intent intent = new Intent(Activity2.this, MainActivity.class);
        startActivity(intent);
    }
*/
}

